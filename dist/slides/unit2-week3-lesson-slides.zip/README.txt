Computer Science ATAR - Unit 2 Week 3: Normalisation
Four editable PowerPoint decks, 8 slides each. Speaker notes include timings, prompts and explained answers.
The classroom-resources folder contains fictional starter reservations, eight stage CSVs, a workbook and public explained answers.
Reservation PK: BorrowerID + EquipmentID + ReservationDate. Competing requests are allowed. Normalisation is separate from availability approval and data validation.
Activities are ungraded. No SQL setup or account is required.
Original content CC BY 4.0 https://creativecommons.org/licenses/by/4.0/
Code MIT. See repository licences.
Attribution/source: https://github.com/EdugenIO/cs-atar-textbook
Planner: https://edugenio.github.io/cs-atar-textbook/#teaching
