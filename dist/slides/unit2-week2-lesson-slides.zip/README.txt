Computer Science ATAR - Unit 2 Week 2: Entities and relationships
Four editable PowerPoint decks, 8 slides each. Speaker notes include timing, teaching prompts and explained answers.
The ER diagram uses editable PowerPoint shapes and text. SVG versions and fictional CSV datasets are in classroom-resources with the workbook and public explained answers.
Activities are ungraded. No SQL setup or account is needed.
Original content: CC BY 4.0 https://creativecommons.org/licenses/by/4.0/
Code: MIT. See the repository licences.
Attribution and source: https://github.com/EdugenIO/cs-atar-textbook
Planner/browser slides: https://edugenio.github.io/cs-atar-textbook/#teaching
