Computer Science ATAR - Unit 2 Week 4: Getting started with SQL
Four editable PowerPoint decks, 8 slides each. Teacher notes include timing, prompts and explained answers.
Use a working copy of sql-starter.sqlite in a school-approved SQLite-capable application. Alternatively run sql-setup.sql ONCE in a new empty database. No cloud/student account is required.
The classroom resources include the fictional database, setup/worked SQL, expected results, workbook and explained answers.
This week uses single-table SELECT queries. Activities are ungraded. Reporting date for overdue examples: 8 April 2026. Returned uses integer 0/1 and DueDate uses valid YYYY-MM-DD text in this starter.
Original content CC BY 4.0 https://creativecommons.org/licenses/by/4.0/
Code MIT. See repository licences.
Attribution/source: https://github.com/EdugenIO/cs-atar-textbook
Planner: https://edugenio.github.io/cs-atar-textbook/#teaching
