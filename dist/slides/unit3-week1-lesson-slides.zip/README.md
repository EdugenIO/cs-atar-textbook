# Unit 3 Week 1

Four editable decks, companion practice ZIP and the existing Pygame teaching ZIP. Extract each practice pack into its own writable folder. Student workbook and separate public teacher key are inside the companion ZIP. No student results are supplied.

2027 teaching edition; content CC BY 4.0, code MIT. Suggested timings untrialled; independent moderation pending.

Online: https://edugenio.github.io/cs-atar-textbook/slides/?lesson=u3-w01-l01
