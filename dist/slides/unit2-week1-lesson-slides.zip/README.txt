Computer Science ATAR - Unit 2 Week 1: Database foundations
Four editable PowerPoint decks, 8 slides per lesson.
Speaker notes include suggested timings, teaching prompts and explained answers.
The classroom-resources folder includes fictional data, a workbook and public explained answers.
Reporting date: 8 April 2026. Original overdue rule: unreturned and due strictly before the reporting date.
Activities are ungraded. No SQL installation or account is required.
Content: Creative Commons Attribution 4.0 International (CC BY 4.0).
https://creativecommons.org/licenses/by/4.0/
Code: MIT. See repository licences.
Attribution/source: https://github.com/EdugenIO/cs-atar-textbook
Public planner and browser slides: https://edugenio.github.io/cs-atar-textbook/#teaching
