Computer Science ATAR - Unit 1 lesson slides
64 editable PowerPoint decks, 8 slides each.
Speaker notes include preparation, suggested timing and explained answers.
Original educational content: Creative Commons Attribution 4.0 International (CC BY 4.0).
https://creativecommons.org/licenses/by/4.0/
Code examples: MIT; see the repository for the licence.
Source and attribution: https://github.com/EdugenIO/cs-atar-textbook
Teacher planner, browser slides and notes: https://edugenio.github.io/cs-atar-textbook/#teaching
New activities are ungraded classroom practice.
