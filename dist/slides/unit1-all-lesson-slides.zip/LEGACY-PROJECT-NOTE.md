# Project-slide status

The ten Unit 1 project-workshop decks (u1-w08-l01, u1-w08-l02, u1-w08-l03, u1-w08-l04, u1-w09-l03, u1-w09-l04, u1-w10-l01, u1-w10-l02, u1-w10-l03, u1-w10-l04) retain the older console learning example. They are optional legacy practice, not the current Pygame Task 1. Use https://edugenio.github.io/cs-atar-textbook/#design and its aligned workbook/contract for the current project. Replacement project decks remain A06 work. Other Unit 1 lessons retain their existing purpose.
