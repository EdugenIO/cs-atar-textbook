# Project-slide status

Unit 1 project-workshop presentations now follow the current Pygame brief (S02, 9 November 2026). Earlier console decks and teacher notes are archived at https://edugenio.github.io/cs-atar-textbook/legacy-projects/index.html . Year 12 project presentations remain pending. The ten workshops and shared requirements are unchanged.
