Computer Science ATAR - Unit 2 Week 5: Joins and summaries
Four editable PowerPoint decks, 8 slides each. Speaker notes include timing, prompts and explained answers.
Use a fresh working copy of database-project.sqlite in a school-approved SQLite application. This separate edition adds fictional whole-dollar ReplacementCost estimates. Keep the Week 4 database unchanged.
Classroom resources include the database, setup/report SQL, worked model, workbook and explained answers. This week uses joins and summaries; controlled changes follow in Week 6. No cloud account is required. Activities are ungraded.
Inventory has five items: count 5, total 1400 dollars, mean 280 dollars, minimum 80 dollars, maximum 600 dollars. These are teaching estimates, not prices.
Original content CC BY 4.0 https://creativecommons.org/licenses/by/4.0/
Code MIT. See repository licences.
Attribution/source: https://github.com/EdugenIO/cs-atar-textbook
Planner: https://edugenio.github.io/cs-atar-textbook/#teaching
