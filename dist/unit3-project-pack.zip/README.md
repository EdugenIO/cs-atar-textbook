# Year 12 current Pygame project pack

Read unit3-project-brief.md and unit3-project-workbook.md. Choose ONE ZIP in theme-starters, extract it to a learning folder, then follow that starter’s setup instructions. The five themes use identical year-level requirements and challenge. Common criteria/fixtures/asset policies are unchanged. The shell is runnable infrastructure; student game logic is unfinished.

Workshop budget: 12. Prerequisite Pygame preparation must occur before issue in the agreed sequence. Classroom trial/moderation is still required. The old console project is not this task. Content CC BY 4.0; code MIT.
