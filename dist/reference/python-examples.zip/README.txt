Python reference examples
Use an installed Python 3 interpreter. No extra packages.
Run each file separately: python 01-structure.py
Expected results and explanations are in the web guides.
The files example writes/overwrites scores.txt in the working folder: run it in a fresh practice folder. All other examples use supplied fixtures; input and repeat-until examples simulate keyboard entries.
Original code MIT; see textbook licence.
