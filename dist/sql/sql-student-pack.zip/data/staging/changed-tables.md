# STAGING changed data dictionary, records and relationships
All records are fictional. ISO dates are text; 0/1 is the declared Boolean convention. SQLite affinity is not full domain enforcement.

## Member
Field | Declared type | NOT NULL flag | Primary-key position
--- | --- | --- | ---
MemberID | TEXT | 1 | 1
DisplayName | TEXT | 1 | 0

Supplied records:
MemberID | DisplayName
--- | ---

## Staging
Field | Declared type | NOT NULL flag | Primary-key position
--- | --- | --- | ---
RowNo | INTEGER | 0 | 1
MemberID | TEXT | 1 | 0
DisplayName | TEXT | 1 | 0

Supplied records:
RowNo | MemberID | DisplayName
--- | --- | ---
1 |  m05  |  Faye 
2 | M05 | Conflicting person
3 | M06 |  
4 | m07 |  Gia
